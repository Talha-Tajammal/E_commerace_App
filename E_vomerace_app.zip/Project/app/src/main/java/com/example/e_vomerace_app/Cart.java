package com.example.e_vomerace_app;
import java.util.ArrayList;

public class Cart {
    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }

    public Cart() {
        user=new User();
        products= new ArrayList<Product>();    }

    public String getCart_id() {
        return cart_id;
    }

    public void setCart_id(String cart_id) {
        this.cart_id = cart_id;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }



    private String cart_id;
    private int quantity;
    private User user;
    private ArrayList<Product> products;
}
