package com.example.e_vomerace_app;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    User user;
    private BottomNavigationView bottomNavigationView;
    private FragmentContainerView fragmentContainer;

    private Fragment fragment1;
    private Fragment fragment2;
    private Fragment fragment3;
    private Fragment fragment4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.nav_view);
        fragmentContainer = findViewById(R.id.fragment_view);

        fragment1 = new dashboard();
        fragment2 = new wishlist_fragment();


        fragment3 = new cart_fragment();
        fragment4 = new Setting_fragment();

        setInitialFragment(fragment1);
        String message = getIntent().getStringExtra("uid");
//        if (message != null) {
//            Toast.makeText(this, message, Toast.LENGTH_LONG).show();}
//        else {
//                Toast.makeText(this, "msg is null", Toast.LENGTH_LONG).show();
//            }
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        setFragment(fragment1);
                        return true;
                    case R.id.wishlist:
                        setFragment(fragment2);
                        return true;
                    case R.id.cart:
                        setFragment(fragment3);
                        return true;
                    case R.id.account:
                        setFragment(fragment4);
                        return true;
                }
                return false;
            }
        });
    }

    private void setInitialFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_view, fragment);
        fragmentTransaction.commit();
    }

    private void setFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        String uid = getIntent().getStringExtra("uid");
        Bundle args = fragment.getArguments();

        if (args == null) {
            args = new Bundle();
        }
        args.putString("uid", uid);
        fragment.setArguments(args);

        fragmentTransaction.replace(R.id.fragment_view, fragment);
        fragmentTransaction.commit();
    }


}