package com.example.e_vomerace_app;
import java.util.ArrayList;


public class Payment {
    private String  payment_ID;
    private String payment_method;
    private float amount;
    private boolean payment_conformation;
    private User user;

    public String getPayment_ID() {
        return payment_ID;
    }

    public void setPayment_ID(String payment_ID) {
        this.payment_ID = payment_ID;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public boolean isPayment_conformation() {
        return payment_conformation;
    }

    public void setPayment_conformation(boolean payment_conformation) {
        this.payment_conformation = payment_conformation;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ArrayList<Product> getProducts() {
        return Products;
    }

    public void setProducts(ArrayList<Product> products) {
        Products = products;
    }

    private ArrayList<Product> Products;
}
