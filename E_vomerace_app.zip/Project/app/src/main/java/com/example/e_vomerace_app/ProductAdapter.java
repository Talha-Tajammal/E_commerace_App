package com.example.e_vomerace_app;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class ProductAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Product> myList;
    private LayoutInflater inflater;
    public ProductAdapter(Fragment fragment, ArrayList<Product> list) {
        this.context = fragment.requireContext();
        this.myList = list;
        inflater = LayoutInflater.from(context);
    }
    public ProductAdapter(Context context, ArrayList<Product> list) {
        this.context = context;
        this.myList = list;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return myList.size();
    }

    @Override
    public Product getItem(int position) {
        return myList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_item, parent, false);
            holder = new ViewHolder();
            holder.productImage = convertView.findViewById(R.id.product_image);
            holder.productName = convertView.findViewById(R.id.product_name);
            holder.productPrice = convertView.findViewById(R.id.product_price);
            convertView.setTag(holder);
        } else {

            holder = (ViewHolder) convertView.getTag();
        }

        Product product = getItem(position);

        // Assuming the product image is stored as a URI string
        Uri imageUriString = product.getImage();
        if (imageUriString != null) {
            holder.productImage.setImageURI(product.getImage());
        } else {

        }

        holder.productName.setText(product.getProduct_name());
        holder.productPrice.setText("Rs: "+product.getPrice());

        return convertView;
    }

    private static class ViewHolder {
        ImageView productImage;
        TextView productName;
        TextView productPrice;
    }
}
