package com.example.e_vomerace_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ProductAdapter_RecyclerView extends RecyclerView.Adapter<ProductAdapter_RecyclerView.ViewHolder> {
    private Context context;
    private ArrayList<Product> myList;
    private LayoutInflater inflater;

    public ProductAdapter_RecyclerView(Context context, ArrayList<Product> list) {
        this.context = context;
        this.myList = list;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Product product = myList.get(position);

        // Assuming the product image is stored as a URI string
        // holder.productImage.setImageURI(product.getImage());
        holder.productName.setText(product.getProduct_name());
        holder.productPrice.setText("Rs: " + product.getPrice());
    }

    @Override
    public int getItemCount() {
        return myList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;
        TextView productName;
        TextView productPrice;

        public ViewHolder(View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.product_image);
            productName = itemView.findViewById(R.id.product_name);
            productPrice = itemView.findViewById(R.id.product_price);
        }
    }
}
