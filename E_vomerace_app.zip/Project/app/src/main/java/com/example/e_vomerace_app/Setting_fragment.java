package com.example.e_vomerace_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;

public class Setting_fragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    Button input_item1,update_user,prod_crud,history,logout;

    private String mParam1;
    private String mParam2;
    private String uid;

    private TabLayout tabLayout;
    private ViewPager2 viewPager;

    public Setting_fragment() {
        // Required empty public constructor
    }

    public static Setting_fragment newInstance(String param1, String param2) {
        Setting_fragment fragment = new Setting_fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting_, container, false);
        Bundle args = getArguments();
        if (args != null) {
            uid = args.getString("uid");
//             Use the UID as needed
//            if (uid != null) {
//                Toast.makeText(getContext(), "uid"+uid, Toast.LENGTH_LONG).show();
//            } else {
//                Toast.makeText(getContext(), "uid is null", Toast.LENGTH_LONG).show();
//            }
        }
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        input_item1 = view.findViewById(R.id.item_insert);
        update_user = view.findViewById(R.id.account_up);
        prod_crud = view.findViewById(R.id.pro_crud);
        history = view.findViewById(R.id.history_list);
        logout = view.findViewById(R.id.logout);


        // Set click listeners for the buttons
        input_item1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), input_item.class);
                intent.putExtra("uid", uid);
                startActivity(intent);
            }
        });

        update_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), user_update.class);
                intent.putExtra("uid", uid);
                startActivity(intent);
            }
        });

        prod_crud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), product_crud.class);
                intent.putExtra("uid", uid);
                startActivity(intent);

            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), history.class);
                intent.putExtra("uid", uid);
                startActivity(intent);

            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), log_in.class));
            }
        });

    }
}
