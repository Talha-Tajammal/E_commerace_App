package com.example.e_vomerace_app;

public class User {
    private String user_name;
    private String user_ID;
    private String Email;
    private String Address;

    public void setUser_type(String user_type) {
        this.user_type = user_type;
    }

    private String contact;

    public User( String email, String password) {
        Email = email;
        this.password = password;
    }

    public String getUser_type() {
        return user_type;
    }

    private String user_type;

    private String  password;

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_ID() {
        return user_ID;
    }

    public User(String user_name, String email, String address, String contact) {
        this.user_name = user_name;
        Email = email;
        Address = address;
        this.contact = contact;
    }public User() {}

    public void setUser_ID(String user_ID) {
        this.user_ID = user_ID;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
