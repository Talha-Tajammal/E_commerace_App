//package com.example.e_vomerace_app;
//import androidx.annotation.NonNull;
//import androidx.fragment.app.Fragment;
//import androidx.viewpager2.adapter.FragmentStateAdapter;
//
//public class ViewPagerAdapter extends FragmentStateAdapter {
//    private static final int NUM_PAGES = 3;
//
//    public ViewPagerAdapter(@NonNull Fragment fragment) {
//        super(fragment);
//    }
//
////    @NonNull
////    @Override
////    public Fragment createFragment(int position) {
////        switch (position) {
////            case 0:
////                return new product_crud();
////            case 1:
////                return new update_user_info();
////            case 2:
////                return new logout_frag();
////            default:
////                return null;
////        }
////    }
////    @Override
////    public long getItemId(int position) {
////        // Return a unique ID for each fragment based on its position
////        return position;
////    }
////
////    @Override
////    public int getItemCount() {
////        return NUM_PAGES;
////    }
//}
