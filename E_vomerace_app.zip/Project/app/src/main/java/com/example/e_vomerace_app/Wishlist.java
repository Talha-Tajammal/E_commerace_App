package com.example.e_vomerace_app;
import java.util.ArrayList;


public class Wishlist {
    private String wishlist_ID;
    private String date;
    private User user;
    private ArrayList<Product> products;

    public String getWishlist_ID() {
        return wishlist_ID;
    }

    public void setWishlist_ID(String wishlist_ID) {
        this.wishlist_ID = wishlist_ID;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }
}
