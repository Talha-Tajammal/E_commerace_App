package com.example.e_vomerace_app;

import static android.net.Uri.parse;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class cart_fragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private String uid;
    private ArrayList<Product> productList;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference productsRef = db.collection("carts");
    ProductAdapter adapter;

    private TextView pay;
    Button don;
    private ListView li;

    public cart_fragment() {
        // Required empty public constructor
    }

    public static cart_fragment newInstance(String param1, String param2) {
        cart_fragment fragment = new cart_fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart_fragment, container, false);
        // Replace "fragment_cart" with the correct layout resource ID for the cart fragment

        Bundle args = getArguments();
        if (args != null) {
            uid = args.getString("uid");
        }

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        li = view.findViewById(R.id.listview_cart);

        registerForContextMenu(li); // Register the ListView for the context menu

        pay=view.findViewById(R.id.payment);
        productList = new ArrayList<>();
        adapter = new ProductAdapter(requireContext(), productList);
        li.setAdapter(adapter);

        don=view.findViewById(R.id.done_btn);
        don.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showConfirmationDialog();
            }
        });



        productsRef.whereEqualTo("user_ID", uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                productList.clear(); // Clear the list before adding new products
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Product product = new Product();
                    product.setProduct_ID(document.getString("product_ID"));
                    product.setProduct_name(document.getString("product_name"));
                    String imageUriString = document.getString("image");
                    if (imageUriString != null) {
                        product.setImage(parse(imageUriString));
                    } else {

                    }
                    product.setPrice(document.getString("price"));
                    product.setQuantity(document.getString("quantity"));
                    product.setCategory(document.getString("category"));
                    product.setDistribution(document.getString("distribution"));
                    productList.add(product);
                    Log.d("DATA tag","Size: "+productList.size());
                }
                payment();
                adapter.notifyDataSetChanged();
            } else {
                // Handle the error
                Log.d("tag", "Error getting documents: ", task.getException());
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        requireActivity().getMenuInflater().inflate(R.menu.cart_crud, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;
        Product selectedProduct = productList.get(position);
        switch (item.getItemId()) {
            case R.id.menu_delete_from_cart:
                // Handle update action
                remove_from_cart(selectedProduct);
                return true;
            case R.id.menu_insert_in_wishlist:
                // Handle delete action
                insert_into_wishlist(selectedProduct);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }
    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Confirmation");
        builder.setMessage("Thanks for purchasing product.\nAre you sure you want to proceed.");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                moveProductsToHistory();
            }
        });

        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void moveProductsToHistory() {
        // Remove all products from the cart
        productsRef.whereEqualTo("user_ID", uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    document.getReference().delete();
                }
                Toast.makeText(getContext(), "All products removed from cart", Toast.LENGTH_SHORT).show();
                productList.clear();
                adapter.notifyDataSetChanged();
            } else {
                // Handle the error
                Toast.makeText(getContext(), "Error removing products from cart", Toast.LENGTH_SHORT).show();
            }
        });

        // Move the products to history (assuming there's a collection called "history")
        for (Product product : productList) {
            product.setUser_ID(uid);

            db.collection("history").document(product.getProduct_ID())
                    .set(product);

        }

        Toast.makeText(getContext(), "Products moved to history", Toast.LENGTH_SHORT).show();
        payment();
    }




    private void remove_from_cart(Product selectedProduct) {
        CollectionReference productsRef1 = FirebaseFirestore.getInstance().collection("carts");

        Query query = productsRef1.whereEqualTo("product_ID", selectedProduct.getProduct_ID());

        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    productsRef1.document(document.getId()).delete()
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(getContext(), "Product deleted: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
                                // Remove the selected product from the list
                                productList.remove(selectedProduct);
                                // Notify the adapter about the change
                                adapter.notifyDataSetChanged();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(getContext(), "Failed to delete product: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
                            });
                }
            } else {
                // Handle the error
                Toast.makeText(getContext(), "Error retrieving product: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void insert_into_wishlist(Product selectedProduct) {
        selectedProduct.setUser_ID(uid);
        Toast.makeText(getContext(), "uid: " + uid, Toast.LENGTH_SHORT).show();
        db.collection("wishlists").document(selectedProduct.getProduct_ID())
                .set(selectedProduct)
                .addOnCompleteListener(TaskExecutors.MAIN_THREAD, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(getContext(), "Inserted into wishlist", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Failed to insert into wishlist", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void payment() {
        int total_payment = 0;
        for (Product product : productList) {
            int price = Integer.parseInt(product.getPrice());
            total_payment += price;
        }
        pay.setText("Total payment: " + total_payment);
    }
}