package com.example.e_vomerace_app;

import static android.net.Uri.parse;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class dashboard extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String uid;
    ProductAdapter adapter;
    private ArrayList<Product> productList;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private CollectionReference productsRef = db.collection("products");


    private EditText search1;
    private ArrayList<Product> searchResultsList;
    private ListView li;
//    ProductAdapter adapter;

    private String mParam1;
    private String mParam2;

    public dashboard() {
        // Required empty public constructor
    }

    public static dashboard newInstance(String param1, String param2) {
        dashboard fragment = new dashboard();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);
        // Replace "fragment_dashboard" with the correct layout resource ID

        Bundle args = getArguments();
        if (args != null) {
            uid = args.getString("uid");
        }

        return view;
    }



    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        li = view.findViewById(R.id.listview_dashboard);
        registerForContextMenu(li); // Register the ListView for the context menu
        search1 = view.findViewById(R.id.search);
        productList = new ArrayList<>();
        adapter = new ProductAdapter(requireContext(), productList);
        li.setAdapter(adapter);
        searchResultsList = new ArrayList<>();


        li.setOnItemClickListener((parent, view1, position, id) -> {
            Product selectedProduct = productList.get(position);
            Intent intent = new Intent(getContext(), item_detail.class);
            intent.putExtra("product_ID", selectedProduct.getProduct_ID());
            startActivity(intent);
        });

        search1.setOnEditorActionListener((v, actionId, event) -> {

                String searchText = search1.getText().toString();
                performSearch(searchText);
                return true;

        });

        productsRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                productList.clear();
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Product product = new Product();
                    product.setProduct_ID(document.getString("product_ID"));
                    product.setProduct_name(document.getString("product_name"));
                    String imageUriString = document.getString("image");
                    if (imageUriString != null) {
                        product.setImage(parse(imageUriString));
                    } else {

                    }
                    product.setPrice(document.getString("price"));
                    product.setQuantity(document.getString("quantity"));
                    product.setCategory(document.getString("category"));
                    product.setDistribution(document.getString("distribution"));
                    productList.add(product);
                    Log.d("DATA tag","Size: "+productList.size());
                }
                adapter.notifyDataSetChanged();
            } else {
                // Handle the error
                Log.d("tag", "Error getting documents: ", task.getException());
            }
        });
    }

    private void performSearch(String searchText) {
        searchResultsList.clear();

        for (Product product : productList) {
            if (product.getProduct_name().toLowerCase().contains(searchText.toLowerCase())) {
                searchResultsList.add(product);
                Log.d("DATA tag","Size searach: "+searchResultsList.size());
            }
        }

        adapter = new ProductAdapter(requireContext(), searchResultsList); // Update the adapter with search results
        li.setAdapter(adapter); // Update the ListView with the new adapter
        adapter.notifyDataSetChanged();
    }




    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        requireActivity().getMenuInflater().inflate(R.menu.dasdboard_crud, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;
        Product selectedProduct = productList.get(position);
        switch (item.getItemId()) {
            case R.id.menu_insert_in_cart:
                // Handle update action
                insert_into_cart(selectedProduct);
                return true;
            case R.id.menu_insert_in_wishlist:
                // Handle delete action
                insert_into_wishlist(selectedProduct);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }


    private void insert_into_cart(Product selectedProduct) {
        selectedProduct.setUser_ID(uid);
        db.collection("carts").document(selectedProduct.getProduct_ID())
                .set(selectedProduct)
                .addOnCompleteListener(TaskExecutors.MAIN_THREAD, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(getContext(), "Inserted into cart", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Failed to insert into cart", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void insert_into_wishlist(Product selectedProduct) {
        selectedProduct.setUser_ID(uid);
        Toast.makeText(getContext(), "uid: " + uid, Toast.LENGTH_SHORT).show();
        db.collection("wishlists").document(selectedProduct.getProduct_ID())
                .set(selectedProduct)
                .addOnCompleteListener(TaskExecutors.MAIN_THREAD, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(getContext(), "Inserted into wishlist", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Failed to insert into wishlist", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
