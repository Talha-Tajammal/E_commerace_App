package com.example.e_vomerace_app;

import static android.net.Uri.parse;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class history extends AppCompatActivity {
    ListView lis;
    ArrayList<Product> productList;
    ProductAdapter adapter;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    CollectionReference productsRef = db.collection("history");

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        lis=findViewById(R.id.listview_history);
        String uid = getIntent().getStringExtra("uid");

        productList = new ArrayList<>();
        ProductAdapter adapter = new ProductAdapter(this, productList);
        lis.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        productsRef.whereEqualTo("user_ID", uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                productList.clear(); // Clear the list before adding new products
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Product product = new Product();
                    product.setProduct_ID(document.getString("product_ID"));
                    product.setProduct_name(document.getString("product_name"));
                    String imageUriString = document.getString("image");
                    if (imageUriString != null) {
                        product.setImage(parse(imageUriString));
                    } else {

                    }
                    product.setPrice(document.getString("price"));
                    product.setQuantity(document.getString("quantity"));
                    product.setCategory(document.getString("category"));
                    product.setDistribution(document.getString("distribution"));
                    productList.add(product);
                    Log.d("DATA tag","Size: "+productList.size());
                }

                adapter.notifyDataSetChanged();
            } else {
                // Handle the error
                Log.d("tag", "Error getting documents: ", task.getException());
            }
        });

    }
}