package com.example.e_vomerace_app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

public class input_item extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST_CODE = 1;
    Product product;
    Uri image_uri;
    private ImageView imageView;

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private EditText p_name,p_price,p_desc,p_category,p_quantity;
    private Button selectImageButton,ins;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_item);
        String uid = getIntent().getStringExtra("uid");
        p_category=findViewById(R.id.item_category);
        p_name=findViewById(R.id.item_name);
        p_price=findViewById(R.id.item_price);
        p_quantity=findViewById(R.id.item_quantity);
        p_desc=findViewById(R.id.item_distribution);
        imageView = findViewById(R.id.imageView);
        selectImageButton = findViewById(R.id.selectImageButton);
        ins=findViewById(R.id.insert);

        ins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (p_price.getText().toString().isEmpty() || p_quantity.getText().toString().isEmpty()|| p_name.getText().toString().isEmpty()){
                    //Toast.makeText(this, "Fill the required Fields", Toast.LENGTH_SHORT).show();
                    Log.d("tag1","Fill the required Fields");
                }
                else {
                    product =new Product();
                    product.setUser_ID(uid);
                    product.setCategory(p_category.getText().toString());
                    product.setProduct_name(p_name.getText().toString());
                    product.setDistribution(p_desc.getText().toString());
                    product.setQuantity(p_quantity.getText().toString());
                    product.setPrice(p_price.getText().toString());
                    product.setImage(image_uri);

                    String id = db.collection("products").document().getId();
                    product.setProduct_ID(id);
                    db.collection("products").document(id).set(product).addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Log.d("tag1","Product Entered");
                            //Toast.makeText(this, "Product Entered", Toast.LENGTH_SHORT).show();

                        } else {
                            Log.d("tag1","Product Entered fail");
                            //Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
                        }
                        finish();

                    });
                }
            }
        });

        selectImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            image_uri= imageUri;
            Log.d("ImageV",imageUri.toString());
            imageView.setImageURI(imageUri);
        }
    }



}