
package com.example.e_vomerace_app;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

public class item_detail extends AppCompatActivity {

    private TextView productNameTextView;
    private TextView priceTextView;
    private TextView categoryTextView;
    private TextView quantityTextView;
    private TextView descriptionTextView;
    private ImageView productImageView;

    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_detail);

        // Initialize the views
        productNameTextView = findViewById(R.id.name_det);
        priceTextView = findViewById(R.id.pri_det);
        categoryTextView = findViewById(R.id.cata_det);
        quantityTextView = findViewById(R.id.quan_det);
        descriptionTextView = findViewById(R.id.des_det);
        productImageView = findViewById(R.id.img_detail);

        // Retrieve the product ID from the intent

        String productID = getIntent().getStringExtra("product_ID");
//        Toast.makeText(this, "productID_detail_f: "+productID , Toast.LENGTH_SHORT).show();


//         Fetch the product details from the database
        db.collection("products").document(productID).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                DocumentSnapshot document = task.getResult();
                if (document.exists()) {
                    // Get the product details
                    String productName = document.getString("product_name");
                    String price = document.getString("price");
                    String category = document.getString("category");
                    String quantity = document.getString("quantity");
                    String description = document.getString("distribution");
                    String imageUri = document.getString("image");

                    // Set the product details in the views
                    productNameTextView.setText("Name: " + productName);
                    priceTextView.setText("Price: " + price);
                    categoryTextView.setText("Category: " + category);
                    quantityTextView.setText("Quantity: " + quantity);
                    descriptionTextView.setText("Description: " + description);
                    Picasso.get().load(imageUri).placeholder(R.drawable.placeholder_image).into(productImageView);
                }
            }
        });
    }
}
