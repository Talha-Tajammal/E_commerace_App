package com.example.e_vomerace_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class log_in extends AppCompatActivity {
    private AppCompatButton sign_up,login;
    private EditText L_email,L_pass;

    private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.log_in);
        L_email = findViewById(R.id.user_name);
        L_pass = findViewById(R.id.password);
        login= findViewById(R.id.log_in_btn);
        sign_up= findViewById(R.id.sign_up_btn);
        auth = FirebaseAuth.getInstance();

        //login Authentication Codez
        auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();

//        if (user != null && user.isEmailVerified()) {
//            String u_id = auth.getUid();
//
//            Intent intent = new Intent(this, MainActivity.class);
//            intent.putExtra("uid", u_id);
//            startActivity(intent);
//            finish();
//        }


        login.setOnClickListener(v -> {
            if (L_email.getText().toString().isEmpty() || L_pass.getText().toString().isEmpty()) {
                Toast.makeText(this, "Fill the required Fields", Toast.LENGTH_SHORT).show();
            } else {
                String email = L_email.getText().toString();
                String password = L_pass.getText().toString();

                auth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        String u_id=auth.getUid();

                        Toast.makeText(this, "Login successfully", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(this, MainActivity.class);
                        intent.putExtra("uid", u_id);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(this, "email or password is invalid", Toast.LENGTH_SHORT).show();
                    }
                });
            }

        });

        sign_up.setOnClickListener(v -> {
            startActivity(new Intent(this, registration.class));
        });





    }

}