package com.example.e_vomerace_app;

import static android.net.Uri.parse;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class product_crud extends AppCompatActivity {
    ArrayList<Product> productList;
    ProductAdapter adapter;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    CollectionReference productsRef = db.collection("products");

    ListView lis;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_product_crud);
            String uid = getIntent().getStringExtra("uid");
            lis = findViewById(R.id.list_view_pro_crud);


            registerForContextMenu(lis); // Register ListView for context menu

            productList = new ArrayList<>();
            adapter = new ProductAdapter(this, productList); // Remove the local declaration here
            lis.setAdapter(adapter);
            adapter.notifyDataSetChanged();
        productsRef.whereEqualTo("user_ID", uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                productList.clear(); // Clear the list before adding new products
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Product product = new Product();
                    product.setProduct_ID(document.getString("product_ID"));
                    product.setProduct_name(document.getString("product_name"));
                    String imageUriString = document.getString("image");
                    if (imageUriString != null) {
                        product.setImage(parse(imageUriString));
                    } else {

                    }
                    product.setPrice(document.getString("price"));
                    product.setQuantity(document.getString("quantity"));
                    product.setCategory(document.getString("category"));
                    product.setDistribution(document.getString("distribution"));
                    productList.add(product);
                    Log.d("DATA tag","Size: "+productList.size());
                }

                adapter.notifyDataSetChanged();
            } else {
                // Handle the error
                Log.d("tag", "Error getting documents: ", task.getException());
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.popmanu_crud, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;
        Product selectedProduct = productList.get(position);
        switch (item.getItemId()) {
            case R.id.menu_update:
                showUpdateDialog(selectedProduct);
                return true;
            case R.id.menu_delete:
                deleteProduct(selectedProduct);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    private void showUpdateDialog(Product product) {
        Intent intent = new Intent(this, update_pro.class);
        intent.putExtra("product_id", product.getProduct_ID());
        startActivity(intent);
    }

    // foe delete the product
    private void deleteProduct(Product selectedProduct) {
        CollectionReference productsRef1 = FirebaseFirestore.getInstance().collection("products");

        Query query = productsRef1.whereEqualTo("product_ID", selectedProduct.getProduct_ID());

        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    productsRef1.document(document.getId()).delete()
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(this, "Product deleted: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
                                // Remove the selected product from the list
                                productList.remove(selectedProduct);
                                // Notify the adapter about the change
                                adapter.notifyDataSetChanged();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(this, "Failed to delete product: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
                            });
                }
            } else {
                // Handle the error
                Toast.makeText(this, "Error retrieving product: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
