package com.example.e_vomerace_app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class registration extends AppCompatActivity {
    private Button regis_btn;
    private EditText e_mail,password1;

    private User user;
    private FirebaseAuth auth;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);


        e_mail = findViewById(R.id.email);
        password1 = findViewById(R.id.password);
        regis_btn = findViewById(R.id.register_btn);
        auth = FirebaseAuth.getInstance();

        regis_btn.setOnClickListener(view -> {
            if (e_mail.getText().toString().isEmpty() || password1.getText().toString().isEmpty()) {
                Toast.makeText(this, "Fill the required Fields", Toast.LENGTH_SHORT).show();
            } else {
                String email = e_mail.getText().toString();
                String password = password1.getText().toString();

                //Registration Code
                auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(this, "register successfully", Toast.LENGTH_SHORT).show();

                        user = new User(e_mail.getText().toString(),password1.getText().toString());

                        db.collection("users").document(auth.getUid());
                        user.setUser_ID(auth.getUid());

                        db.collection("users").document(auth.getUid()).set(user).addOnCompleteListener(this,task1 -> {
                            if (task1.isSuccessful()){
                                Toast.makeText(this, "register successfully", Toast.LENGTH_SHORT).show();
                            }else {
                                Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
                            }
                        });

                        startActivity(new Intent(this, log_in.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Failed", Toast.LENGTH_SHORT).show();
                    }
                });


            }


        });



    }
}