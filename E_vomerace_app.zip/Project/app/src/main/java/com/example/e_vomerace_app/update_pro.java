package com.example.e_vomerace_app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class update_pro extends AppCompatActivity {
    String prod_id;
    private static final int PICK_IMAGE_REQUEST_CODE = 1;
    private EditText p_name, p_price, p_desc, p_category, p_quantity;
    private Button selectImageButton, ins;
    private ImageView imageView;
    Uri image_uri;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    DocumentReference productRef;
    Product product;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_pro);

        p_category = findViewById(R.id.item_category_u);
        p_name = findViewById(R.id.item_name_u);
        p_price = findViewById(R.id.item_price_u);
        p_quantity = findViewById(R.id.item_quantity_u);
        p_desc = findViewById(R.id.item_distribution_u);
        imageView = findViewById(R.id.imageView_u);
        selectImageButton = findViewById(R.id.selectImageButton_u);
        ins = findViewById(R.id.insert_u);

        Intent intent = getIntent();
        prod_id = intent.getStringExtra("product_id");
        productRef = db.collection("products").document(prod_id);

        ins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (p_price.getText().toString().isEmpty() || p_quantity.getText().toString().isEmpty() || p_name.getText().toString().isEmpty()) {
                    Toast.makeText(update_pro.this, "Fill the required Fields", Toast.LENGTH_SHORT).show();
                } else {
                    Map<String, Object> productData = new HashMap<>();
                    productData.put("product_ID", prod_id);
                    productData.put("category", p_category.getText().toString());
                    productData.put("product_name", p_name.getText().toString());
                    productData.put("distribution", p_desc.getText().toString());
                    productData.put("quantity", p_quantity.getText().toString());
                    productData.put("price", p_price.getText().toString());
                    productData.put("image", image_uri);

                    productRef.update(productData)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // Handle successful update
                                    Toast.makeText(update_pro.this, "Product updated successfully", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Handle error
                                    Toast.makeText(update_pro.this, "Failed to update product: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });

                }
            }
        });

        selectImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE_REQUEST_CODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            image_uri = imageUri;
            Log.d("ImageV", imageUri.toString());
            imageView.setImageURI(imageUri);
        }
    }
}
