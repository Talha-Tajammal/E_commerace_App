package com.example.e_vomerace_app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class user_update extends AppCompatActivity {
    private RadioGroup roleRadioGroup;
    private String role;
    EditText name,addre,pho_n,email,pass;
    Button registerButton;
    private User user;
    private FirebaseAuth auth;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    DocumentReference UserRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_update);
        roleRadioGroup = findViewById(R.id.roleRadioGroup);
        name=findViewById(R.id.user_name);
        addre=findViewById(R.id.Adres);
        pho_n=findViewById(R.id.pho_no);
        auth=FirebaseAuth.getInstance();

        registerButton = findViewById(R.id.update_Btn);
        String uid = getIntent().getStringExtra("uid");
            // Use the UID as needed
//            if (uid != null) {
//                Toast.makeText(this, "uid u_p"+uid, Toast.LENGTH_LONG).show();
//            } else {
//                Toast.makeText(this, "uid u_p is null", Toast.LENGTH_LONG).show();
//            }
        UserRef = db.collection("users").document(uid);




        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().isEmpty() || addre.getText().toString().isEmpty() || pho_n.getText().toString().isEmpty()) {
                    Toast.makeText(user_update.this, "Fill the required Fields", Toast.LENGTH_SHORT).show();
                } else {
                    int selectedId = roleRadioGroup.getCheckedRadioButtonId();

                    if (selectedId == R.id.sellerRadioButton) {
                        role = "Customer";
                    } else if (selectedId == R.id.customerRadioButton) {
                        role = "Seller";
                    } else {
                        // Handle the case where no role is selected
                        return;
                    }

                    Map<String, Object> userData = new HashMap<>();
                    userData.put("user_ID", uid);
                    userData.put("user_name", name.getText().toString());
                    userData.put("address", addre.getText().toString());
                    userData.put("contact", pho_n.getText().toString());
                    userData.put("user_type", role);

                    UserRef.update(userData)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // Handle successful update
                                    Toast.makeText(user_update.this, "User updated successfully", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Handle error
                                    Toast.makeText(user_update.this, "User to update product: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                }


            }


        });
    }
}

//