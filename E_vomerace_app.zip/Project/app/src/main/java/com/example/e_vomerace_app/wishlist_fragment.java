package com.example.e_vomerace_app;

import static android.net.Uri.parse;

import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.TaskExecutors;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class wishlist_fragment extends Fragment {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private String uid;
    ArrayList<Product> productList;
    private ListView li;
    ProductAdapter adapter;
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    CollectionReference productsRef = db.collection("wishlists");

    ListView lis;


    public wishlist_fragment() {
        // Required empty public constructor
    }


    public static wishlist_fragment newInstance(String param1, String param2) {
        wishlist_fragment fragment = new wishlist_fragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_wishlist_fragment, container, false);
        Bundle args = getArguments();
        if (args != null) {
            uid = args.getString("uid");
//             Use the UID as needed
//            if (uid != null) {
//                Toast.makeText(getContext(), "uid w "+uid, Toast.LENGTH_LONG).show();
//            } else {
//                Toast.makeText(getContext(), "uid w is null", Toast.LENGTH_LONG).show();
//            }
        }
        return view;
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        li = view.findViewById(R.id.listview_wishlist);
        registerForContextMenu(li); // Register the ListView for the context menu


        productList = new ArrayList<>();
        adapter = new ProductAdapter(requireContext(), productList);
        li.setAdapter(adapter);

        productsRef.whereEqualTo("user_ID", uid).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                productList.clear(); // Clear the list before adding new products
                for (QueryDocumentSnapshot document : task.getResult()) {
                    Product product = new Product();
                    product.setProduct_ID(document.getString("product_ID"));
                    product.setProduct_name(document.getString("product_name"));
                    String imageUriString = document.getString("image");
                    if (imageUriString != null) {
                        product.setImage(parse(imageUriString));
                    } else {

                    }

                    product.setPrice(document.getString("price"));
                    product.setQuantity(document.getString("quantity"));
                    product.setCategory(document.getString("category"));
                    product.setDistribution(document.getString("distribution"));
                    productList.add(product);
                    Log.d("DATA tag","Size: "+productList.size());
                }

                adapter.notifyDataSetChanged();
            } else {
                // Handle the error
                Log.d("tag", "Error getting documents: ", task.getException());
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        requireActivity().getMenuInflater().inflate(R.menu.wishlist_crud, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;
        Product selectedProduct = productList.get(position);
        switch (item.getItemId()) {
            case R.id.menu_remove_from_wishlist:
                // Handle delete action
                remove_from_wishlist(selectedProduct);
                return true;
            case R.id.menu_insert_in_cart:
                // Handle insertion action
                insert_into_cart(selectedProduct);
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    private void remove_from_wishlist(Product selectedProduct) {
        CollectionReference productsRef1 = FirebaseFirestore.getInstance().collection("wishlists");

        Query query = productsRef1.whereEqualTo("product_ID", selectedProduct.getProduct_ID());

        query.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                for (QueryDocumentSnapshot document : task.getResult()) {
                    productsRef1.document(document.getId()).delete()
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(getContext(), "Product deleted: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
                                // Remove the selected product from the list
                                productList.remove(selectedProduct);
                                // Notify the adapter about the change
                                adapter.notifyDataSetChanged();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(getContext(), "Failed to delete product: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
                            });
                }
            } else {
                // Handle the error
                Toast.makeText(getContext(), "Error retrieving product: " + selectedProduct.getProduct_name(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void insert_into_cart(Product selectedProduct) {
        selectedProduct.setUser_ID(uid);
        db.collection("carts").document(selectedProduct.getProduct_ID())
                .set(selectedProduct)
                .addOnCompleteListener(TaskExecutors.MAIN_THREAD, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(getContext(), "Inserted into cart", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), "Failed to insert into cart", Toast.LENGTH_SHORT).show();
                    }
                });
    }


}